# a-gsuplementos
pensamento computacional
